=== Antigravity Booking ===
Contributors: Antigravity
Tags: booking, schedule
Stable tag: 1.0.0
Requires at least: 5.0
Tested up to: 6.0
Requires PHP: 7.4
License: GPLv2 or later

Custom booking plugin with time blocks, cost estimation, and Google Calendar sync.
