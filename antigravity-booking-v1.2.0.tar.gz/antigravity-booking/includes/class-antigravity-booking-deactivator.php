<?php
class Antigravity_Booking_Deactivator {
	public static function deactivate() {
        // Deactivation logic
	}
}
