<?php
class Antigravity_Booking_Activator {
	public static function activate() {
        // Activation logic
	}
}
