<?php

/**
 * Handles AJAX requests for the booking plugin
 */
class Antigravity_Booking_API
{

    public function __construct()
    {
        // Availability Endpoint
        add_action('wp_ajax_antigravity_get_availability', array($this, 'get_availability'));
        add_action('wp_ajax_nopriv_antigravity_get_availability', array($this, 'get_availability'));

        // Booking Creation Endpoint
        add_action('wp_ajax_antigravity_create_booking', array($this, 'create_booking'));
        add_action('wp_ajax_nopriv_antigravity_create_booking', array($this, 'create_booking'));
    }

    /**
     * Get available time slots for a specific date
     */
    public function get_availability()
    {
        check_ajax_referer('antigravity_booking_nonce', 'nonce');

        $date_str = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        if (!$date_str) {
            wp_send_json_error('Invalid date.');
        }

        // 1. Check if date is generally available (day of week, blackout)
        // We assume 00:00 to 23:59 for global day check
        $start_of_day = $date_str . ' 00:00:00';
        $end_of_day = $date_str . ' 23:59:59';

        $day_check = Antigravity_Booking_Availability::check_availability($start_of_day, $end_of_day);

        // If the day is completely blocked (e.g. "Mondays are unavailable"), fail early
        // BUT: specific time slots might be failing in this check if we passed full day range
        // So we need to be careful. check_availability checks specific times.
        // Let's rely on generating slots and checking each one.

        // Get configured hours for this day
        $day_name = strtolower(date('l', strtotime($date_str)));
        $hours_per_day = get_option('antigravity_booking_hours_per_day', array());

        if (!isset($hours_per_day[$day_name])) {
            // Fallback if not set, or maybe closed?
            // Actually check_availability handles the "Is day available" check logic better.
            // If day is not in 'available_days' option, it's closed.
            $available_days = get_option('antigravity_booking_available_days', array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'));
            if (!in_array($day_name, $available_days)) {
                wp_send_json_error('We are closed on ' . ucfirst($day_name) . 's.');
            }
        }

        $business_start = isset($hours_per_day[$day_name]['start']) ? $hours_per_day[$day_name]['start'] : '09:00';
        $business_end = isset($hours_per_day[$day_name]['end']) ? $hours_per_day[$day_name]['end'] : '17:00';

        // Generate slots (e.g. every hour)
        // TODO: Make slot duration configurable? defaulting to 1 hour for now.
        $slots = array();
        $current = strtotime("$date_str $business_start");
        $end_ts = strtotime("$date_str $business_end");

        // Loop through the day in 1-hour increments
        while ($current < $end_ts) {
            $slot_start = date('H:i', $current);
            $slot_end_ts = strtotime('+1 hour', $current);
            $slot_end = date('H:i', $slot_end_ts);

            // Construct datetime strings
            $dt_start = "$date_str $slot_start";
            $dt_end = "$date_str $slot_end"; // This might cross midnight if we support late nights, but simple for now

            // Check availability for this specific slot
            $availability = Antigravity_Booking_Availability::check_availability($dt_start, $dt_end);

            // Also check against EXISTING bookings (overlap check)
            // This is crucial. check_availability only checks RULES, not DB collisions.
            $is_blocked = $this->is_slot_booked($dt_start, $dt_end);

            if ($availability['available'] && !$is_blocked) {
                $slots[] = array(
                    'start' => $slot_start,
                    'end' => $slot_end, // 1 hour duration
                    'label' => date('g:i A', $current) . ' - ' . date('g:i A', $slot_end_ts)
                );
            }

            $current = $slot_end_ts;
        }

        // Add overnight slot if enabled for this day
        $overnight_start = get_option('antigravity_booking_overnight_cutoff', '22:00');
        $overnight_dt = "$date_str $overnight_start";

        if (Antigravity_Booking_Availability::is_overnight_booking($overnight_dt)) {

            // Check collision for overnight
            $overnight_end = Antigravity_Booking_Availability::get_overnight_end($overnight_dt);
            $is_blocked = $this->is_slot_booked($overnight_dt, $overnight_end);

            if (!$is_blocked) {
                $slots[] = array(
                    'start' => $overnight_start,
                    'end' => 'Overnight',
                    'label' => date('g:i A', strtotime($overnight_dt)) . ' (Overnight)',
                    'is_overnight' => true
                );
            }
        }

        wp_send_json_success($slots);
    }

    /**
     * Check if a slot overlaps with existing approved/pending bookings
     */
    private function is_slot_booked($start_dt, $end_dt)
    {
        $args = array(
            'post_type' => 'booking',
            'post_status' => array('approved', 'pending_review'), // Draft/expired don't block
            'posts_per_page' => -1,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_booking_end_datetime',
                    'value' => $start_dt,
                    'compare' => '>',
                    'type' => 'DATETIME'
                ),
                array(
                    'key' => '_booking_start_datetime',
                    'value' => $end_dt,
                    'compare' => '<',
                    'type' => 'DATETIME'
                )
            )
        );

        $query = new WP_Query($args);
        return $query->found_posts > 0;
    }

    /**
     * Handle booking submission
     */
    public function create_booking()
    {
        check_ajax_referer('antigravity_booking_nonce', 'nonce');

        $date = sanitize_text_field($_POST['date']);
        $start_time = sanitize_text_field($_POST['start_time']);
        // If not overnight, we might calculate end time. 
        // Or receive it? Let's assume 1 hour duration if not overnight for now, 
        // OR rely on the frontend to pass duration? 
        // Requirement said "time-block", usually implies hourly. 
        // Let's assume start_time is passed, end_time is start+1hr unless overnight.
        $customer_name = sanitize_text_field($_POST['customer_name']);
        $customer_email = sanitize_email($_POST['customer_email']);

        if (!$date || !$start_time || !$customer_name || !$customer_email) {
            wp_send_json_error('Missing required fields.');
        }

        $start_datetime = "$date $start_time";

        // Check if end_time was passed (from multi-slot selection)
        if (isset($_POST['end_time']) && !empty($_POST['end_time'])) {
            $end_time = sanitize_text_field($_POST['end_time']);

            if ($end_time === 'Overnight') {
                // Handled below by overnight logic, or get explicit time?
                // If frontend sends 'Overnight' string, we need to calculate.
                // But frontend renderSlots puts actual time? 
                // Let's check handleSlotClick JS logic: `this.$inputEndTime.val(endTime);`
                // For overnight slot, end is 'Overnight' string in existing API get_availability logic?
                // Let's check get_availability response structure.
            }

            // Special handling for 'Overnight' string if passed
            if ($end_time === 'Overnight') {
                $end_datetime = Antigravity_Booking_Availability::get_overnight_end($start_datetime);
                $is_overnight = true;
            } else {
                // Standard time string
                // Handle crossing midnight manually if needed, but assuming date is same unless overnight logic triggers.
                // If end_time < start_time and NOT overnight, that's an issue (or next day).
                // Our frontend logic ensures continuity.

                // Construct datetime.
                // If end time is e.g. 00:00, it's next day.
                // If explicit end time is passed, we construct it.
                // Basic assumption: Booking is on same day unless overnight logic applies.
                // But wait, if I select 2pm to 6pm, end is 6pm.
                $end_datetime = "$date $end_time";
                $is_overnight = false;
            }
        } else {
            // Fallback to single slot logic
            if (Antigravity_Booking_Availability::is_overnight_booking($start_datetime)) {
                $end_datetime = Antigravity_Booking_Availability::get_overnight_end($start_datetime);
                $is_overnight = true;
            } else {
                $end_datetime = date('Y-m-d H:i', strtotime($start_datetime . ' +1 hour'));
                $is_overnight = false;
            }
        }

        // Final Availability Check
        $avail = Antigravity_Booking_Availability::check_availability($start_datetime, $end_datetime, $is_overnight);
        if (!$avail['available']) {
            wp_send_json_error(implode(' ', $avail['errors']));
        }

        if ($this->is_slot_booked($start_datetime, $end_datetime)) {
            wp_send_json_error('This slot was just booked by someone else. Please try another.');
        }

        // Create Post
        $post_data = array(
            'post_title' => $customer_name . ' - ' . $start_datetime,
            'post_status' => 'pending_review',
            'post_type' => 'booking'
        );

        $post_id = wp_insert_post($post_data);
        if (is_wp_error($post_id)) {
            wp_send_json_error('Failed to create booking.');
        }

        // Save Meta
        update_post_meta($post_id, '_booking_start_datetime', $start_datetime);
        update_post_meta($post_id, '_booking_end_datetime', $end_datetime);
        update_post_meta($post_id, '_customer_name', $customer_name);
        update_post_meta($post_id, '_customer_email', $customer_email);

        // New Fields
        $phone = isset($_POST['customer_phone']) ? sanitize_text_field($_POST['customer_phone']) : '';
        $guests = isset($_POST['guest_count']) ? intval($_POST['guest_count']) : 0;
        $desc = isset($_POST['event_description']) ? sanitize_textarea_field($_POST['event_description']) : '';

        update_post_meta($post_id, '_customer_phone', $phone);
        update_post_meta($post_id, '_guest_count', $guests);
        update_post_meta($post_id, '_event_description', $desc);

        update_post_meta($post_id, '_is_overnight', $is_overnight);

        // Calculate Cost
        $cp = new Antigravity_Booking_CPT(); // Helper to calculate cost
        $cost = $cp->calculate_cost($post_id);
        update_post_meta($post_id, '_estimated_cost', $cost);

        // Trigger Emails (Status Transition to Pending handled in CPT class? Or separate hook?)
        // Currently emails are sent on "save_post" or status transition.
        // Let's ensure we trigger the "submission" email. 
        // We do this manually here for explicit control or rely on hooks. 
        // For now, let's rely on the fact that we just inserted a post.
        // Actually, we need to send the "Submission Confirmation" email.

        ob_start();
        $mailer = new Antigravity_Booking_Emails();
        $mailer->send_submission_email($post_id);
        ob_end_clean(); // Discard any output from email sending (e.g. SMTP debug)

        $redirect_url = get_option('antigravity_booking_success_redirect', '');
        error_log("Antigravity Booking Debug - Redirect URL: " . $redirect_url);

        wp_send_json_success(array(
            'message' => 'Booking submitted successfully! We will review it shortly.',
            'redirect_url' => $redirect_url
        ));
    }
}
